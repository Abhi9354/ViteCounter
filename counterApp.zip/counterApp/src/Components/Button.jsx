import './Button.css'
const Button = (props)=>{
    const click = ()=>{
      props.fn(props.name)
    }
    console.log(props)
    return (<div>
        <button onClick={click} className="mybutton">{props.name}</button>
    </div>)
}
export default Button;