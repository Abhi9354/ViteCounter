import Button from "./Components/Button";
import "./App.css";
import { useEffect, useState } from "react";
// const arr = [{plus:'+'}]

const App = () => {
  const arr = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0", ".", "(", ")"];
  const arr2 = ["+", "*", "/", "%"];
  //For result screen
  const [header2, setheader2] = useState("none");

  //controls header1 values
  const [display, setdisplay] = useState("");
  const [dvalue, setdvalue] = useState("");

  //Controls header2 value
  const [final, setfinal] = useState("");
  const [value, setValue] = useState("");
  useEffect(() => {
    console.log("jasfh", final);
  }, [final]);

  useEffect(() => {
    console.log("valueis", value);
  }, [value]);

  //OnClicking Numberic Values
  const numericHandle = (name) => {
    setdvalue(dvalue + name);
    setdisplay(() => dvalue + name);
    setValue(value + name);
  };

  //for Handling minus
  const handleminus = (name) => {
    setdvalue(dvalue + name);
    setdisplay(() => dvalue + name);
    if (dvalue == "") {
      setValue(() => value + name);
      return;
    }
    setfinal((prev) => prev + parseInt(value) + name);

    setValue("");
  };

  //OnClicking Operators except minus
  const handlesOperators = (name) => {
    setdvalue(dvalue + name);
    setdisplay(() => dvalue + name);
    // console.log("opeerator",final)

    setfinal((prev) => prev + parseInt(value) + name);
    // console.log("opeerator",final)
    setValue("");
  };

  //for the result on screen onclick '='
  const result = () => {
    setheader2("block");
    setfinal((prev) => eval(prev + parseInt(value)));
  };

  //'AC' button handling
  const reset = () => {
    setdisplay("");
    setValue("");
    setfinal("");
    setdvalue("");
    setheader2("none");
  };

  return (
    <div className="app">
      <h1>{display}</h1>
      <br />
      <h2 style={{ display: `${header2}` }}>{final}</h2>
      <div className="container">
        {arr.map((e, i) => {
          console.log(e, i);
          return <Button fn={numericHandle} name={e} key={i} />;
        })}
        {arr2.map((e, i) => {
          console.log(e, i);
          return <Button fn={handlesOperators} name={e} key={i} />;
        })}
        <Button fn={handleminus} name="-" />
        <Button fn={result} name="=" />
        <Button fn={reset} name="AC" />
      </div>
    </div>
  );
};
export default App;
